document.addEventListener('DOMContentLoaded', function() {
    // Verificar la geolocalización del usuario
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(checkLocation, handleLocationError);
    } else {
        alert('Tu navegador no soporta la geolocalización.');
    }

    // Función para verificar la ubicación del usuario
    function checkLocation(position) {
        const userLatitude = position.coords.latitude;
        const userLongitude = position.coords.longitude;

        // Coordenadas de Riberalta, Beni, Bolivia
        const riberaltalatitude = -11.0058;
        const riberaltalongitude = -66.0641;

        // Calcular la distancia entre la ubicación del usuario y Riberalta
        const distance = calculateDistance(userLatitude, userLongitude, riberaltalatitude, riberaltalongitude);

        // Verificar si la distancia está dentro del rango permitido (60 km)
        if (distance <= 60) {
            // Mostrar el contenido de la página
            document.body.style.display = 'block';
            loadNewsItems();
        } else {
            // Mostrar mensaje de restricción geográfica
            alert('Lo siento, esta página solo está disponible en Riberalta, Beni, Bolivia y a 60 kilómetros alrededor de la ciudad.');
            document.body.style.display = 'none';
        }
    }

    // Función para calcular la distancia entre dos coordenadas
    function calculateDistance(lat1, lon1, lat2, lon2) {
        const earthRadius = 6371; // Radio de la Tierra en kilómetros
        const dLat = deg2rad(lat2 - lat1);
        const dLon = deg2rad(lon2 - lon1);
        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = earthRadius * c;
        return distance;
    }

    // Función para convertir grados a radianes
    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

    // Función para manejar errores de geolocalización
    function handleLocationError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                alert('Permiso de geolocalización denegado por el usuario.');
                break;
            case error.POSITION_UNAVAILABLE:
                alert('Información de geolocalización no disponible.');
                break;
            case error.TIMEOUT:
                alert('Tiempo de espera agotado al obtener la geolocalización.');
                break;
            default:
                alert('Error desconocido al obtener la geolocalización.');
                break;
        }
        document.body.style.display = 'none';
    }

    // Función para cargar las noticias desde la base de datos
    function loadNewsItems() {
        // Aquí debes implementar la lógica para obtener las noticias desde la base de datos
        // y mostrarlas en el contenedor de noticias (.news-items)
        // Puedes usar AJAX o fetch para hacer una solicitud al servidor y obtener los datos
        // Luego, genera dinámicamente el HTML para cada noticia y agrégalo al contenedor
    }

    // Función para alternar entre el reproductor de VDO Ninja y el reproductor de YouTube
    function togglePlayer(playerId) {
        const vdoNinjaPlayer = document.getElementById('vdoNinjaPlayer');
        const youtubePlayer = document.getElementById('youtubePlayer');

        if (playerId === 'vdoNinjaPlayer') {
            vdoNinjaPlayer.style.display = 'block';
            youtubePlayer.style.display = 'none';
            // Detener la reproducción del video de YouTube si estaba en curso
            youtubePlayer.innerHTML = '';
        } else if (playerId === 'youtubePlayer') {
            vdoNinjaPlayer.style.display = 'none';
            youtubePlayer.style.display = 'block';
            // Cargar el video de YouTube en el reproductor
            // Aquí debes proporcionar el código embedido del video de YouTube
            youtubePlayer.innerHTML = '<iframe width="100%" height="600" src="https://www.youtube.com/embed/VIDEO_ID" frameborder="0" allowfullscreen></iframe>';
        }
    }

    // Evento de clic para alternar entre los reproductores
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('toggle-player')) {
            const playerId = event.target.dataset.playerId;
            togglePlayer(playerId);
        }
    });
});